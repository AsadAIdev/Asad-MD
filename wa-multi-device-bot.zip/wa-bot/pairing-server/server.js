const express = require('express');
const path = require('path');
const fs = require('fs-extra');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const config = require('../config');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

/**
 * Public pairing website flow:
 * 1. User apna WhatsApp number webpage form mein daalta hai
 * 2. Backend naya auth session banata hai aur Baileys se pairing code maangta hai
 * 3. Code webpage par dikha diya jata hai, user WhatsApp > Linked Devices mein enter karta hai
 * 4. Session files /session/<id> mein save ho jati hain jo main bot (index.js) use karta hai
 */
app.post('/api/pair', async (req, res) => {
  try {
    const { number } = req.body;
    if (!number || !/^\d{10,15}$/.test(number.replace(/\D/g, ''))) {
      return res.status(400).json({ error: 'Sahi WhatsApp number likhein (country code ke sath, spaces/+ ke bina).' });
    }

    const cleanNumber = number.replace(/\D/g, '');
    const sessionDir = path.join(__dirname, '..', 'session', config.sessionId);
    fs.ensureDirSync(sessionDir);

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
      version,
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: 'silent' }),
      browser: ['Chrome (Linux)', 'Chrome', '120.0.0'],
    });

    sock.ev.on('creds.update', saveCreds);

    if (!sock.authState.creds.registered) {
      const code = await sock.requestPairingCode(cleanNumber);
      return res.json({ success: true, code, message: 'WhatsApp > Linked Devices > Link with phone number mein ye code enter karein.' });
    }

    return res.json({ success: true, code: null, message: 'Ye number already linked hai.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Pairing code generate nahi ho saka: ' + err.message });
  }
});

app.get('/api/status', (req, res) => {
  const sessionDir = path.join(__dirname, '..', 'session', config.sessionId);
  const exists = fs.existsSync(path.join(sessionDir, 'creds.json'));
  res.json({ linked: exists });
});

const PORT = config.pairPort;
app.listen(PORT, () => {
  console.log(`✔ Pairing website chal raha hai: http://localhost:${PORT}`);
});
