const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');
const chalk = require('chalk');
const readline = require('readline');
const path = require('path');
const fs = require('fs-extra');

const config = require('./config');
const { loadPlugins } = require('./lib/pluginLoader');

const SESSION_DIR = path.join(__dirname, 'session', config.sessionId);
fs.ensureDirSync(SESSION_DIR);

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: false, // hum pairing code (ya website) use kar rahe hain, QR nahi
    logger: pino({ level: 'silent' }),
    browser: ['Chrome (Linux)', 'Chrome', '120.0.0'],
  });

  // ---- Pairing code flow (agar registered nahi hai) ----
  if (!sock.authState.creds.registered) {
    console.log(chalk.cyan('\nAccount abhi tak registered nahi hai.'));
    const phoneNumber = await question(
      chalk.yellow('WhatsApp number country code ke sath likhein (bina + ya spaces, e.g. 923001234567): ')
    );
    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(phoneNumber.trim());
        console.log(chalk.green(`\nYour Pairing Code: `) + chalk.bold.white(code));
        console.log(chalk.gray('WhatsApp > Linked Devices > Link with phone number > ye code enter karein.\n'));
      } catch (e) {
        console.log(chalk.red('Pairing code generate nahi hua: ' + e.message));
      }
    }, 2500);
  }

  const { commands, categories } = loadPlugins();

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === 'close') {
      const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
      console.log(chalk.red('Connection closed.'), 'Reconnecting:', shouldReconnect);
      if (shouldReconnect) startBot();
    } else if (connection === 'open') {
      console.log(chalk.green(`\n✔ ${config.botName} connected successfully!\n`));
    }
  });

  // ---- Message handler ----
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    const msg = messages[0];
    if (!msg?.message || msg.key.fromMe) return;

    const from = msg.key.remoteJid;
    const isGroup = from.endsWith('@g.us');
    const body =
      msg.message.conversation ||
      msg.message.extendedTextMessage?.text ||
      msg.message.imageMessage?.caption ||
      msg.message.videoMessage?.caption ||
      '';

    if (!body.startsWith(config.prefix)) return;

    const args = body.slice(config.prefix.length).trim().split(/ +/);
    const cmdName = args.shift().toLowerCase();
    const plugin = commands.get(cmdName);

    if (!plugin) return;

    const sender = msg.key.participant || msg.key.remoteJid;
    const isOwner = sender.includes(config.ownerNumber);

    const ctx = {
      config,
      from,
      isGroup,
      sender,
      isOwner,
      categories,
      commandCount: commands.size,
      reply: (text) => sock.sendMessage(from, { text }, { quoted: msg }),
    };

    try {
      await plugin.execute(sock, msg, args, ctx);
    } catch (err) {
      console.log(chalk.red(`[cmd error] ${cmdName}: ${err.message}`));
      await ctx.reply(`❌ Command mein error aaya: ${err.message}`);
    }
  });

  return sock;
}

startBot().catch((err) => console.log(chalk.red('Fatal error: ' + err.message)));
