require('dotenv').config();

module.exports = {
  botName: process.env.BOT_NAME || 'MyWaBot',
  ownerName: process.env.OWNER_NAME || 'Owner',
  ownerNumber: process.env.OWNER_NUMBER || '923000000000',
  prefix: process.env.PREFIX || '.',
  pairPort: process.env.PAIR_SERVER_PORT || 3000,
  publicUrl: process.env.PUBLIC_URL || 'http://localhost:3000',
  ai: {
    apiKey: process.env.AI_API_KEY || '',
    apiUrl: process.env.AI_API_URL || '',
    model: process.env.AI_MODEL || 'llama-3.1-8b-instant',
  },
  sessionId: process.env.SESSION_ID || 'wa-session',
};
