# WhatsApp Multi-Device Bot (Baileys) — Full Stack Starter Kit

Ye ek production-style starter hai: Baileys se multi-device WhatsApp bot, public pairing website, aur ek dynamic **plugin system** jo aapko sirf files add kar ke commands ki tadaad barhane deta hai (5, 30, ya 180 tak).

## 📁 Structure
```
wa-bot/
├── index.js              # Main bot - Baileys connect + message router
├── config.js              # .env se config load karta hai
├── lib/pluginLoader.js    # /plugins folder ko dynamically scan karta hai
├── plugins/                # Har command ek alag file
│   ├── general/  (ping, menu, profile, runtime, time)
│   ├── fun/      (joke, quote, dice, coinflip, truthordare)
│   ├── owner/    (broadcast, eval, setprefix)
│   ├── group/    (kick, add, promote, demote, groupinfo, tagall)
│   ├── converter/(sticker, toimg, tourl)
│   ├── ai/       (ai, translate)
│   └── downloader/(ytmp3, ytmp4)
├── pairing-server/
│   ├── server.js           # Express backend - pairing code API
│   └── public/index.html   # Public pairing website (fancy UI)
├── session/                 # Auth session yahan save hoti hai (git-ignore karein)
└── .env.example
```

## 🚀 Setup (Termux / Windows / VPS sab par chalta hai)

```bash
npm install
cp .env.example .env
# .env file kholein aur OWNER_NUMBER, BOT_NAME waghera set karein
```

### Option A — Terminal se pair karein
```bash
npm start
```
Number likhein jab pucha jaye, terminal mein pairing code milega.

### Option B — Public website se pair karein (fancy way)
```bash
npm run pair
```
Browser mein `http://localhost:3000` kholein (ya server URL agar VPS/Render par deploy kiya hai), number daalein, code milega.

Pairing complete hone ke baad, `npm start` chala kar bot activate karein — dono ek hi `/session` folder use karte hain.

## ➕ 30 se 180 commands tak kaise pahunchein

Har command ek independent file hai is shape mein:
```js
module.exports = {
  name: 'commandname',
  alias: ['shortname'],       // optional
  category: 'fun',            // .menu mein isi category ke under dikhega
  description: '...',
  execute: async (sock, msg, args, ctx) => {
    await ctx.reply('response yahan');
  },
};
```
Bas naya `.js` file kisi bhi `/plugins/<category>/` folder mein rakh dein — koi aur file edit karne ki zaroorat nahi, loader khud utha lega. Isi template ko copy-paste kar ke aap news, weather, currency-convert, quiz, games, anti-link, welcome-message, jaisi categories khud barha sakte hain jab tak 180 tak na pahunch jayein.

## ⚠️ Zaroori Notes
- `session/` folder kabhi GitHub par public na karein — is mein aapka WhatsApp session hota hai.
- `owner/eval.js` sirf apne test/development ke liye hai, production mein disable ya remove kar dein agar bot public rakhna hai.
- Downloader commands (ytmp3/ytmp4) mein aapko khud koi legal third-party API integrate karni hogi — is starter mein sirf structure diya gaya hai.
- Naye WhatsApp accounts ko bulk-message bhejne ya spam karne se ban ho sakta hai — responsibly use karein.

## 📦 Deploy options
- **Termux (mobile-only)**: `pkg install nodejs git`, phir upar wale steps.
- **VPS/Render/Railway**: Node 18+ environment, `npm install && npm start`, aur pairing website ko separate service/port par run karein.
