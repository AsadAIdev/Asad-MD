module.exports = {
  name: 'kick',
  category: 'group',
  description: 'Group se member remove karein (reply/mention karke, admin only)',
  execute: async (sock, msg, args, ctx) => {
    if (!ctx.isGroup) return ctx.reply('❌ Ye command sirf groups mein chalta hai.');
    const mentioned = msg.message.extendedTextMessage?.contextInfo?.mentionedJid;
    const quoted = msg.message.extendedTextMessage?.contextInfo?.participant;
    const target = (mentioned && mentioned[0]) || quoted;
    if (!target) return ctx.reply('User ko mention ya reply karein jise kick karna hai.');
    await sock.groupParticipantsUpdate(ctx.from, [target], 'remove');
    await ctx.reply('✔ Member remove kar diya.');
  },
};
