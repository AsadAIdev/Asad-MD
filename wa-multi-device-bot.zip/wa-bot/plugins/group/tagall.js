module.exports = {
  name: 'tagall',
  alias: ['everyone'],
  category: 'group',
  description: 'Sab group members ko mention karein',
  execute: async (sock, msg, args, ctx) => {
    if (!ctx.isGroup) return ctx.reply('❌ Sirf groups mein.');
    const meta = await sock.groupMetadata(ctx.from);
    const mentions = meta.participants.map((p) => p.id);
    const text = mentions.map((m) => `@${m.split('@')[0]}`).join(' ');
    await sock.sendMessage(ctx.from, { text, mentions });
  },
};
