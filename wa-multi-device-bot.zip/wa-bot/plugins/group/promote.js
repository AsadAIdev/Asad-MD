module.exports = {
  name: 'promote',
  category: 'group',
  description: 'Member ko admin banayein (reply/mention karke)',
  execute: async (sock, msg, args, ctx) => {
    if (!ctx.isGroup) return ctx.reply('❌ Sirf groups mein.');
    const mentioned = msg.message.extendedTextMessage?.contextInfo?.mentionedJid;
    const quoted = msg.message.extendedTextMessage?.contextInfo?.participant;
    const target = (mentioned && mentioned[0]) || quoted;
    if (!target) return ctx.reply('User mention/reply karein.');
    await sock.groupParticipantsUpdate(ctx.from, [target], 'promote');
    await ctx.reply('✔ Admin bana diya.');
  },
};
