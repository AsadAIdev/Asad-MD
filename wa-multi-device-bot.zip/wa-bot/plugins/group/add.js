module.exports = {
  name: 'add',
  category: 'group',
  description: 'Group mein number add karein - .add 923xxxxxxxxx',
  execute: async (sock, msg, args, ctx) => {
    if (!ctx.isGroup) return ctx.reply('❌ Sirf groups mein.');
    if (!args[0]) return ctx.reply('Number likhein: .add 923xxxxxxxxx');
    const jid = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    await sock.groupParticipantsUpdate(ctx.from, [jid], 'add');
    await ctx.reply('✔ Add kar diya.');
  },
};
