module.exports = {
  name: 'demote',
  category: 'group',
  description: 'Admin se member banayein (reply/mention karke)',
  execute: async (sock, msg, args, ctx) => {
    if (!ctx.isGroup) return ctx.reply('❌ Sirf groups mein.');
    const mentioned = msg.message.extendedTextMessage?.contextInfo?.mentionedJid;
    const quoted = msg.message.extendedTextMessage?.contextInfo?.participant;
    const target = (mentioned && mentioned[0]) || quoted;
    if (!target) return ctx.reply('User mention/reply karein.');
    await sock.groupParticipantsUpdate(ctx.from, [target], 'demote');
    await ctx.reply('✔ Demote kar diya.');
  },
};
