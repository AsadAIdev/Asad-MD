module.exports = {
  name: 'groupinfo',
  alias: ['ginfo'],
  category: 'group',
  description: 'Group ki info dikhayein',
  execute: async (sock, msg, args, ctx) => {
    if (!ctx.isGroup) return ctx.reply('❌ Sirf groups mein.');
    const meta = await sock.groupMetadata(ctx.from);
    await ctx.reply(`📌 *${meta.subject}*\n👥 Members: ${meta.participants.length}\n📝 Desc: ${meta.desc || 'N/A'}`);
  },
};
