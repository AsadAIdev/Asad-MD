module.exports = {
  name: 'toimg',
  category: 'converter',
  description: 'Sticker ko image mein convert karein (reply karke)',
  execute: async (sock, msg, args, ctx) => {
    await ctx.reply('⚙ Is command ke liye reply karda sticker download karke jpeg buffer mein convert karein (sharp/ffmpeg).');
  },
};
