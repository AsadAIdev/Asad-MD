module.exports = {
  name: 'tourl',
  category: 'converter',
  description: 'Media ko upload karke direct URL dein (reply karke)',
  execute: async (sock, msg, args, ctx) => {
    await ctx.reply('⚙ Media download karke kisi free file-host API (e.g. catbox.moe) par upload karein aur URL return karein.');
  },
};
