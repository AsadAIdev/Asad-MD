module.exports = {
  name: 'menu',
  alias: ['help', 'commands'],
  category: 'general',
  description: 'Sab commands ki list dikhayein, category wise',
  execute: async (sock, msg, args, ctx) => {
    let text = `╭─❖ *${ctx.config.botName}* ❖─╮\n`;
    text += `│ Owner: ${ctx.config.ownerName}\n`;
    text += `│ Prefix: ${ctx.config.prefix}\n`;
    text += `│ Total Commands: ${ctx.commandCount}\n`;
    text += `╰────────────────╯\n\n`;
    for (const [cat, cmds] of Object.entries(ctx.categories)) {
      text += `*⟪ ${cat.toUpperCase()} ⟫*\n`;
      text += cmds.map((c) => `  ➤ ${ctx.config.prefix}${c}`).join('\n');
      text += '\n\n';
    }
    await ctx.reply(text.trim());
  },
};
