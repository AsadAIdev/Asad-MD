const moment = require('moment-timezone');
module.exports = {
  name: 'time',
  category: 'general',
  description: 'Current time dikhayein (Pakistan timezone)',
  execute: async (sock, msg, args, ctx) => {
    const t = moment().tz('Asia/Karachi').format('dddd, DD MMMM YYYY - hh:mm:ss A');
    await ctx.reply(`🕒 ${t}`);
  },
};
