module.exports = {
  name: 'ping',
  category: 'general',
  description: 'Bot ka response speed check karein',
  execute: async (sock, msg, args, ctx) => {
    const start = Date.now();
    const latency = Date.now() - start;
    await ctx.reply(`🏓 Pong! ${latency}ms`);
  },
};
