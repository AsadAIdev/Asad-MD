module.exports = {
  name: 'runtime',
  alias: ['uptime'],
  category: 'general',
  description: 'Bot kitni der se chal raha hai',
  execute: async (sock, msg, args, ctx) => {
    const s = process.uptime();
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = Math.floor(s % 60);
    await ctx.reply(`⏱ Uptime: ${h}h ${m}m ${sec}s`);
  },
};
