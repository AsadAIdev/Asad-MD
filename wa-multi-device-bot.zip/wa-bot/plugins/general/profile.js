module.exports = {
  name: 'profile',
  alias: ['whoami'],
  category: 'general',
  description: 'Apna WhatsApp profile info dekhein',
  execute: async (sock, msg, args, ctx) => {
    await ctx.reply(`👤 Number: ${ctx.sender.split('@')[0]}\n👑 Owner: ${ctx.isOwner ? 'Yes' : 'No'}\n📍 Chat type: ${ctx.isGroup ? 'Group' : 'Private'}`);
  },
};
