module.exports = {
  name: 'coinflip',
  alias: ['toss'],
  category: 'fun',
  description: 'Coin toss - Heads ya Tails',
  execute: async (sock, msg, args, ctx) => {
    await ctx.reply(`🪙 ${Math.random() > 0.5 ? 'Heads' : 'Tails'}`);
  },
};
