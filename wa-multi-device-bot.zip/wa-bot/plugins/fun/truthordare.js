const truths = ['Tumhara sab se embarrassing moment kya tha?', 'Kabhi kisi se jhoot bola?'];
const dares = ['Apna favorite gana 10 second gaao', 'Ek funny selfie bhejo'];
module.exports = {
  name: 'truthordare',
  alias: ['tod'],
  category: 'fun',
  description: 'Random truth ya dare',
  execute: async (sock, msg, args, ctx) => {
    const isTruth = Math.random() > 0.5;
    const item = isTruth ? truths[Math.floor(Math.random() * truths.length)] : dares[Math.floor(Math.random() * dares.length)];
    await ctx.reply(`${isTruth ? '🗣 Truth' : '🔥 Dare'}: ${item}`);
  },
};
