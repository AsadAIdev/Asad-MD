const jokes = [
  'Teacher: Tum late kyun aaye? Student: Sir raste mein ek board tha "School Ahead - Go Slow"',
  'Main: Sapno mein bhi WiFi chahiye. Wife: Reality mein router bhi off hai.',
  'Dost: Diet start ki hai. 5 min baad: Samosay le lo, kal se start karunga.',
];
module.exports = {
  name: 'joke',
  category: 'fun',
  description: 'Random Roman Urdu joke bhejta hai',
  execute: async (sock, msg, args, ctx) => {
    const j = jokes[Math.floor(Math.random() * jokes.length)];
    await ctx.reply(`😂 ${j}`);
  },
};
