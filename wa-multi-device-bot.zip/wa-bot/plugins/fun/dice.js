module.exports = {
  name: 'dice',
  alias: ['roll'],
  category: 'fun',
  description: 'Dice roll karein (1-6)',
  execute: async (sock, msg, args, ctx) => {
    await ctx.reply(`🎲 Aap ne roll kiya: ${Math.ceil(Math.random() * 6)}`);
  },
};
