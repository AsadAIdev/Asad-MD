const quotes = [
  'Mushkil waqt hamesha nahi rehta, hausla rakho.',
  'Jo mehnat karta hai, wahi manzil paata hai.',
  'Har raat ke baad subah zaroor aati hai.',
];
module.exports = {
  name: 'quote',
  category: 'fun',
  description: 'Motivational quote bhejta hai',
  execute: async (sock, msg, args, ctx) => {
    await ctx.reply(`✨ ${quotes[Math.floor(Math.random() * quotes.length)]}`);
  },
};
