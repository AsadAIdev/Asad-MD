module.exports = {
  name: 'broadcast',
  alias: ['bc'],
  category: 'owner',
  description: '(Owner only) Sab groups mein message bhejein',
  execute: async (sock, msg, args, ctx) => {
    if (!ctx.isOwner) return ctx.reply('❌ Ye command sirf owner use kar sakta hai.');
    if (!args.length) return ctx.reply('Message likhein: .broadcast <text>');
    const groups = await sock.groupFetchAllParticipating();
    const ids = Object.keys(groups);
    for (const id of ids) {
      await sock.sendMessage(id, { text: `📢 *Broadcast*\n\n${args.join(' ')}` });
    }
    await ctx.reply(`✔ ${ids.length} groups mein bhej diya.`);
  },
};
