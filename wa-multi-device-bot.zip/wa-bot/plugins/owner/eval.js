module.exports = {
  name: 'eval',
  category: 'owner',
  description: '(Owner only) JS code run karein - development ke liye',
  execute: async (sock, msg, args, ctx) => {
    if (!ctx.isOwner) return ctx.reply('❌ Sirf owner ke liye.');
    try {
      const result = eval(args.join(' '));
      await ctx.reply(`✅ Result:\n${String(result)}`);
    } catch (e) {
      await ctx.reply(`❌ Error: ${e.message}`);
    }
  },
};
