module.exports = {
  name: 'setprefix',
  category: 'owner',
  description: '(Owner only) Bot ka prefix note - runtime mein config file edit karein',
  execute: async (sock, msg, args, ctx) => {
    if (!ctx.isOwner) return ctx.reply('❌ Sirf owner ke liye.');
    await ctx.reply(`Current prefix: ${ctx.config.prefix}\n(.env file mein PREFIX change karke bot restart karein)`);
  },
};
