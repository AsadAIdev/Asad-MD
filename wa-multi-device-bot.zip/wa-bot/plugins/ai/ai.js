const axios = require('axios');
module.exports = {
  name: 'ai',
  alias: ['ask', 'gpt'],
  category: 'ai',
  description: 'AI se sawal poochein - .ai <question>',
  execute: async (sock, msg, args, ctx) => {
    if (!args.length) return ctx.reply('Sawal likhein: .ai <question>');
    if (!ctx.config.ai.apiKey || !ctx.config.ai.apiUrl) {
      return ctx.reply('⚙ .env mein AI_API_KEY aur AI_API_URL set karein (e.g. Groq free tier).');
    }
    try {
      const res = await axios.post(
        ctx.config.ai.apiUrl,
        {
          model: ctx.config.ai.model,
          messages: [{ role: 'user', content: args.join(' ') }],
        },
        { headers: { Authorization: `Bearer ${ctx.config.ai.apiKey}` } }
      );
      const reply = res.data.choices?.[0]?.message?.content || 'Response nahi mila.';
      await ctx.reply(`🤖 ${reply}`);
    } catch (e) {
      await ctx.reply(`❌ AI error: ${e.message}`);
    }
  },
};
