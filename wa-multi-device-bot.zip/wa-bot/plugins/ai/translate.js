const axios = require('axios');
module.exports = {
  name: 'translate',
  alias: ['tr'],
  category: 'ai',
  description: 'Text translate karein - .translate en <text>',
  execute: async (sock, msg, args, ctx) => {
    if (args.length < 2) return ctx.reply('Usage: .translate <lang_code> <text>\nExample: .translate en Aap kaise hain');
    const lang = args.shift();
    const text = args.join(' ');
    try {
      const res = await axios.get('https://api.mymemory.translated.net/get', {
        params: { q: text, langpair: `auto|${lang}` },
      });
      await ctx.reply(`🌐 ${res.data.responseData.translatedText}`);
    } catch (e) {
      await ctx.reply('❌ Translate service abhi available nahi.');
    }
  },
};
